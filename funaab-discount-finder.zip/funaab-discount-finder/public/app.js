(function () {
  "use strict";

  var CATEGORIES = ["Food", "Books", "Tech and print", "Shopping"];
  var TZ = "Africa/Lagos";
  var DAY = 86400000;
  var DAY_NAMES = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  var STATUS_LABEL = {
    confirmed: "Confirmed with shop",
    reported: "Reported in FUNAAB news",
    sample: "Sample offer \u2013 not confirmed"
  };

  var state = {
    shops: [], user: null, loading: true, loadError: "",
    q: "", cat: "All", openOnly: false, savedOnly: false,
    editing: null, armed: null, view: "list", fill: null, found: []
  };

  var $ = function (id) { return document.getElementById(id); };
  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  /* ---------- API ---------- */
  function api(method, url, body) {
    var opts = { method: method, credentials: "same-origin", headers: {} };
    if (body !== undefined) { opts.headers["Content-Type"] = "application/json"; opts.body = JSON.stringify(body); }
    return fetch(url, opts).then(function (r) {
      return r.text().then(function (text) {
        var data = null;
        try { data = JSON.parse(text); } catch (e) { /* not JSON */ }
        if (!r.ok || data === null) {
          var err = new Error((data && data.error) || "Something went wrong. Try again.");
          err.status = r.status; err.notJson = data === null;
          throw err;
        }
        return data;
      });
    });
  }
  function explainLoadError(e) {
    if (e && e.notJson) {
      return "The server sent back a web page (status " + e.status + ") instead of the shop list. This usually means the site is hosted as a static site, so the back end is not running. Deploy it as a Node web service with the start command \u201cnpm start\u201d.";
    }
    if (e && e.status >= 500) return "The server had an error (status " + e.status + "). Open the Logs tab on your host to see why.";
    if (e && e.status) return "The server refused the request (status " + e.status + "): " + e.message;
    return "Your phone could not reach the server. If your internet works, the server may be asleep or stopped. Wait a minute and try again.";
  }
  function loadShops() {
    return api("GET", "/api/shops").then(function (d) {
      state.shops = d.shops; state.loadError = "";
    }).catch(function (e) {
      state.loadError = explainLoadError(e);
    }).then(function () { state.loading = false; });
  }

  /* ---------- live time in Abeokuta ---------- */
  function lagosNow() {
    var parts = new Intl.DateTimeFormat("en-US", {
      timeZone: TZ, weekday: "short", hour: "numeric", minute: "numeric", hourCycle: "h23"
    }).formatToParts(new Date());
    var o = {};
    parts.forEach(function (p) { o[p.type] = p.value; });
    return { day: DAY_NAMES.indexOf(o.weekday), min: (parseInt(o.hour, 10) % 24) * 60 + parseInt(o.minute, 10) };
  }
  function fmt(min) {
    if (min >= 1440) min = 0;
    var h = Math.floor(min / 60), m = min % 60, ap = h >= 12 ? "PM" : "AM";
    return (h % 12 === 0 ? 12 : h % 12) + ":" + (m < 10 ? "0" : "") + m + " " + ap;
  }
  function openStatus(shop) {
    if (!shop.hours) return { kind: "unknown", open: false, text: "Opening hours not listed" };
    var n = lagosNow(), today = shop.hours[n.day];
    if (today && n.min >= today[0] && n.min < today[1]) {
      if (today[0] === 0 && today[1] === 1440) return { kind: "yes", open: true, text: "Open now \u2013 open 24 hours" };
      return { kind: "yes", open: true, text: "Open now \u2013 closes " + fmt(today[1]) };
    }
    for (var i = 0; i < 7; i++) {
      var d = (n.day + i) % 7, h = shop.hours[d];
      if (!h) continue;
      if (i === 0 && n.min < h[0]) return { kind: "no", open: false, text: "Closed \u2013 opens today at " + fmt(h[0]) };
      if (i > 0) return { kind: "no", open: false, text: "Closed \u2013 opens " + (i === 1 ? "tomorrow" : DAY_NAMES[d]) + " at " + fmt(h[0]) };
    }
    return { kind: "no", open: false, text: "Closed" };
  }
  function updateClock() {
    $("clock").textContent = "Abeokuta time: " + new Intl.DateTimeFormat("en-GB", {
      timeZone: TZ, weekday: "long", hour: "numeric", minute: "2-digit", hour12: true
    }).format(new Date());
  }

  /* ---------- helpers ---------- */
  function norm(s) { return String(s).toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9 ]/g, "").trim(); }
  function ageText(s) {
    if (!s.checkedAt) return "Not checked with the shop yet";
    var t = new Date(s.checkedAt).getTime();
    if (s.status === "reported") return "Reported " + new Date(t).toLocaleDateString("en-GB", { month: "long", year: "numeric", timeZone: "UTC" });
    var d = Math.floor((Date.now() - t) / DAY);
    if (d <= 0) return "Checked today";
    if (d === 1) return "Checked yesterday";
    return "Checked " + d + " days ago";
  }
  function isStale(s) { return !s.checkedAt || (Date.now() - new Date(s.checkedAt).getTime()) > 30 * DAY; }
  function isAdmin() { return state.user && state.user.role === "admin"; }
  function stubParts(discount) {
    var m = discount.match(/^(\d+%)\s*(.*)$/);
    if (m) return { big: m[1], small: m[2] || "off" };
    if (/^free/i.test(discount)) return { big: "Free", small: discount.replace(/^free\s*/i, "") || "for students" };
    return { big: "Deal", small: "" };
  }
  function mapUrl(s) {
    var q = s.lat != null && s.lng != null ? s.lat + "," + s.lng : encodeURIComponent(s.name + " " + s.address + " Abeokuta");
    return "https://www.google.com/maps/search/?api=1&query=" + q;
  }
  function filtered() {
    var q = norm(state.q);
    return state.shops.filter(function (s) {
      if (state.cat !== "All" && s.category !== state.cat) return false;
      if (state.openOnly && !openStatus(s).open) return false;
      if (state.savedOnly && !s.favorite) return false;
      if (q && norm(s.name).indexOf(q) === -1) return false;
      return true;
    });
  }

  /* ---------- render ---------- */
  function initials(name) {
    var p = String(name).trim().split(/\s+/);
    return ((p[0] || "?").charAt(0) + (p.length > 1 ? p[p.length - 1].charAt(0) : "")).toUpperCase();
  }
  function renderWho() {
    var u = state.user;
    if (!u) {
      $("who").innerHTML = '<a class="pill" href="/login">Log in</a><a class="pill solid" href="/signup">Sign up</a>';
      return;
    }
    $("who").innerHTML =
      '<div class="acct">' +
        '<button type="button" class="acct-btn" id="acctBtn" aria-haspopup="true" aria-expanded="false" aria-controls="acctMenu" aria-label="Account menu for ' + esc(u.name) + '">' +
          '<span class="avatar" aria-hidden="true">' + esc(initials(u.name)) + '</span><span class="acct-name">' + esc(u.name.split(" ")[0]) + '</span></button>' +
        '<div class="menu" id="acctMenu" hidden>' +
          '<div class="m-name">' + esc(u.name) + '</div><div class="m-mail">' + esc(u.email) + '</div>' +
          '<div class="m-id"><span>Your student ID</span><b>' + esc(u.id) + '</b></div>' +
          (u.role === "admin" ? '<div class="m-id"><span>Role</span><b>Admin</b></div>' : "") +
          '<button type="button" class="btn ghost" id="logoutBtn">Log out</button>' +
        '</div></div>';
  }
  function setMenu(open) {
    var btn = $("acctBtn"), menu = $("acctMenu");
    if (!btn || !menu) return;
    menu.hidden = !open; btn.setAttribute("aria-expanded", String(open));
  }

  function renderFilters() {
    var h = '<button class="chip" data-cat="All" aria-pressed="' + (state.cat === "All") + '">All types</button>';
    CATEGORIES.forEach(function (c) {
      h += '<button class="chip" data-cat="' + esc(c) + '" aria-pressed="' + (state.cat === c) + '">' + esc(c) + "</button>";
    });
    h += '<span class="divider" aria-hidden="true"></span><button class="chip" data-open="1" aria-pressed="' + state.openOnly + '">Open now</button>';
    if (state.user) h += '<button class="chip" data-saved="1" aria-pressed="' + state.savedOnly + '">Saved</button>';
    $("filters").innerHTML = h;
  }

  function renderResults() {
    if (state.loading) { $("results").innerHTML = '<div class="loading">Loading shops\u2026</div>'; $("count").textContent = ""; return; }
    if (state.loadError) { $("results").innerHTML = '<div class="empty"><h2>Shops did not load</h2><p>' + esc(state.loadError) + '</p><p style="margin-top:14px"><button type="button" class="btn" data-retry="1">Try again</button></p></div>'; $("count").textContent = ""; return; }

    var list = filtered(), q = state.q.trim(), out = "";
    if (!list.length) {
      out = '<div class="empty"><h2>' + (state.savedOnly ? "No saved shops yet" : "No discount found") + "</h2><p>" +
        (state.savedOnly ? "Tap Save on a shop to keep it here."
          : q ? "We have no student discount listed for \u201c" + esc(q) + "\u201d. Ask the shop before you pay, or try another name."
          : "No shops match these filters. Try another type or turn off Open now.") + "</p></div>";
      $("count").textContent = "";
    } else {
      $("count").textContent = list.length + (list.length === 1 ? " shop" : " shops") +
        (q ? " match \u201c" + q + "\u201d" : (state.cat !== "All" ? " in " + state.cat : " near FUNAAB")) + (state.openOnly ? ", open now" : "");
      var admin = isAdmin();
      list.forEach(function (s) {
        var p = stubParts(s.discount), st = openStatus(s), stale = isStale(s);
        out += '<div class="cell" id="shop-' + s.id + '"><article class="ticket">' +
          '<div class="stub"><div class="big">' + esc(p.big) + '</div><div class="small">' + esc(p.small) + "</div></div>" +
          '<div class="body"><div class="title-row"><h2>' + esc(s.name) + "</h2>" +
            '<button class="save" data-save="' + s.id + '" aria-pressed="' + s.favorite + '">' + (s.favorite ? "Saved" : "Save") + "</button></div>" +
          '<div class="meta"><span class="tag">' + esc(s.category) + '</span><span class="tag ' + esc(s.status) + '">' + esc(STATUS_LABEL[s.status] || "") + "</span></div>" +
          '<div class="open ' + st.kind + '">' + esc(st.text) + "</div>" +
          '<div class="row"><b>Discount:</b> ' + esc(s.discount) + "</div>" +
          '<div class="row"><b>How to claim:</b> ' + esc(s.claim) + "</div>" +
          '<div class="row"><b>Address:</b> ' + esc(s.address) + "</div>" +
          (s.note ? '<div class="note">' + esc(s.note) + "</div>" : "") +
          '<div class="links"><a href="' + esc(mapUrl(s)) + '" target="_blank" rel="noopener">Directions</a>' +
            (s.phone ? '<a href="tel:' + esc(s.phone.replace(/[^+\d]/g, "")) + '">Call ' + esc(s.phone) + "</a>" : "") +
            (/^https?:\/\//.test(s.source) ? '<a href="' + esc(s.source) + '" target="_blank" rel="noopener">Source</a>' : "") + "</div>" +
          '<div class="checked' + (admin && stale ? " stale" : "") + '">' + esc(ageText(s)) + (admin && stale ? " \u2013 needs a monthly check" : "") + "</div>" +
          (admin ? '<div class="admin-actions"><button class="mini" data-edit="' + s.id + '">Edit</button>' +
            '<button class="mini" data-verify="' + s.id + '">Mark as confirmed today</button>' +
            '<button class="mini danger' + (state.armed === s.id ? " armed" : "") + '" data-del="' + s.id + '">' +
            (state.armed === s.id ? "Confirm delete" : "Delete") + "</button></div>" : "") +
          "</div></article></div>";
      });
    }
    $("results").innerHTML = out;
    syncMap(list);
  }

  /* ---------- live map (OpenStreetMap + Leaflet) ---------- */
  var map = null, pins = null, lastKey = "", meDot = null;
  var CAMPUS = [7.231, 3.4383];
  function ensureMap() {
    if (map) return true;
    if (!window.L) {
      $("map").innerHTML = '<div class="map-fail">The map could not load. Check your connection and refresh.</div>';
      return false;
    }
    map = L.map("map", { scrollWheelZoom: false }).setView(CAMPUS, 14);
    L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
      maxZoom: 19, attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a> contributors'
    }).addTo(map);
    pins = L.layerGroup().addTo(map);
    map.on("focus", function () { map.scrollWheelZoom.enable(); });
    map.on("blur", function () { map.scrollWheelZoom.disable(); });
    return true;
  }
  function popupHtml(s) {
    var st = openStatus(s);
    return '<span class="pop-name">' + esc(s.name) + "</span>" + esc(s.discount) +
      '<div class="open ' + st.kind + '">' + esc(st.text) + "</div>" +
      '<div class="pop-links"><a href="' + esc(mapUrl(s)) + '" target="_blank" rel="noopener">Directions</a>' +
      '<a href="#shop-' + s.id + '" data-goto="' + s.id + '">Show details</a></div>';
  }
  function syncMap(list, force) {
    if (!map || state.view !== "map") return;
    pins.clearLayers();
    var pts = [];
    list.forEach(function (s) {
      if (s.lat == null || s.lng == null) return;
      var icon = L.divIcon({ className: "pin", html: '<span class="pin-dot"></span>', iconSize: [28, 28], iconAnchor: [14, 28], popupAnchor: [0, -26] });
      L.marker([s.lat, s.lng], { icon: icon, title: s.name, alt: s.name }).bindPopup(popupHtml(s)).addTo(pins);
      pts.push([s.lat, s.lng]);
    });
    var key = list.map(function (s) { return s.id; }).join(",");
    if (pts.length && (force || key !== lastKey)) map.fitBounds(L.latLngBounds(pts).pad(0.25), { maxZoom: 16 });
    lastKey = key;
  }
  function setView(v) {
    state.view = v;
    Array.prototype.forEach.call(document.querySelectorAll(".seg-btn"), function (b) {
      b.setAttribute("aria-pressed", String(b.dataset.view === v));
    });
    $("results").hidden = v === "map";
    $("mapWrap").hidden = v !== "map";
    if (v === "map" && ensureMap()) { map.invalidateSize(); syncMap(filtered(), true); }
  }
  function locateMe() {
    var msg = $("locateMsg");
    if (!navigator.geolocation) { msg.textContent = "Your browser cannot share your location."; return; }
    msg.textContent = "Finding you\u2026";
    navigator.geolocation.getCurrentPosition(function (pos) {
      msg.textContent = "";
      if (!ensureMap()) return;
      var ll = [pos.coords.latitude, pos.coords.longitude];
      if (meDot) meDot.remove();
      meDot = L.circleMarker(ll, { radius: 9, color: "#fff", weight: 3, fillColor: "#1a73e8", fillOpacity: 1 }).addTo(map).bindTooltip("You are here");
      map.setView(ll, 16);
    }, function () { msg.textContent = "Could not get your location. Allow location access and try again."; }, { enableHighAccuracy: true, timeout: 12000 });
  }
  function goToShop(id) {
    setView("list");
    var el = $("shop-" + id);
    if (!el) return;
    el.scrollIntoView({ behavior: "smooth", block: "center" });
    el.classList.add("flash");
    setTimeout(function () { el.classList.remove("flash"); }, 1800);
  }

  function renderAll() {
    renderWho(); renderFilters(); renderResults();
    $("adminPanel").hidden = !isAdmin();
  }

  /* ---------- auth ---------- */
  function maybeWelcome() {
    var flag = false;
    try { flag = sessionStorage.getItem("sdf_welcome") === "1"; sessionStorage.removeItem("sdf_welcome"); } catch (e) {}
    if (!flag || !state.user) return;
    $("welcome").hidden = false;
    $("welcome").innerHTML = '<div><b>Welcome, ' + esc(state.user.name.split(" ")[0]) + '.</b> Your student ID is <b>' + esc(state.user.id) +
      '</b>. You can now save shops.</div><button type="button" id="welcomeClose">Close</button>';
  }
  function logout() {
    api("POST", "/api/auth/logout").catch(function () {}).then(function () {
      state.user = null; state.savedOnly = false; state.armed = null; $("welcome").hidden = true;
      return loadShops();
    }).then(renderAll);
  }

  /* ---------- saved shops ---------- */
  function toggleSave(id) {
    if (!state.user) { window.location.assign("/login"); return; }
    var s = state.shops.filter(function (x) { return x.id === id; })[0];
    if (!s) return;
    var want = !s.favorite;
    s.favorite = want; renderResults();
    api(want ? "PUT" : "DELETE", "/api/favorites/" + id).catch(function () {
      s.favorite = !want; renderResults();
    });
  }

  /* ---------- admin ---------- */
  function setMsg(t, cls) { var m = $("formMsg"); m.textContent = t; m.className = "msg " + (cls || ""); }
  function resetForm() {
    state.editing = null; state.fill = null;
    ["f_name", "f_disc", "f_claim", "f_addr", "f_phone"].forEach(function (id) { $(id).value = ""; });
    $("f_cat").value = CATEGORIES[0]; $("f_status").value = "confirmed";
    $("formTitle").textContent = "Add a new shop"; $("saveBtn").textContent = "Add shop"; $("cancelBtn").hidden = true;
  }
  function saveShop() {
    var payload = {
      name: $("f_name").value, category: $("f_cat").value, discount: $("f_disc").value, claim: $("f_claim").value,
      address: $("f_addr").value, phone: $("f_phone").value, status: $("f_status").value
    };
    if (!payload.name.trim() || !payload.discount.trim() || !payload.claim.trim() || !payload.address.trim()) {
      setMsg("Fill in name, discount, how to claim and address.", "err"); return;
    }
    if (state.fill) {
      payload.lat = state.fill.lat; payload.lng = state.fill.lng; payload.source = state.fill.source;
      if (state.fill.hours) payload.hours = state.fill.hours;
    }
    var editing = state.editing, btn = $("saveBtn");
    btn.disabled = true;
    api(editing ? "PUT" : "POST", editing ? "/api/shops/" + editing : "/api/shops", payload).then(function () {
      setMsg(editing ? "Shop updated." : "Shop added.", "good"); resetForm(); return loadShops();
    }).then(renderAll).catch(function (e) { setMsg(e.message, "err"); }).then(function () { btn.disabled = false; });
  }
  /* ---------- admin: find a shop on the live map and fill the form ---------- */
  function mapMsg(t, cls) { var m = $("m_msg"); m.textContent = t; m.className = "msg " + (cls || ""); }
  function searchMap() {
    var q = $("m_q").value.trim(), btn = $("m_find");
    btn.disabled = true; mapMsg("Searching the map\u2026"); $("m_results").innerHTML = "";
    api("GET", "/api/map/search?q=" + encodeURIComponent(q)).then(function (d) {
      state.found = d.places || [];
      if (!state.found.length) { mapMsg(q ? "No place called \u201c" + q + "\u201d found on the map. Try a shorter name, or fill the form by hand." : "No shops found near FUNAAB on the map.", "err"); return; }
      mapMsg(state.found.length + " found. Tap one to fill the form. " + (d.attribution || ""), "good");
      $("m_results").innerHTML = state.found.map(function (p, i) {
        return '<li><button type="button" class="m-item" data-i="' + i + '"><b>' + esc(p.name) + "</b>" +
          "<span>" + esc(p.category) + " \u2013 " + p.distanceKm + " km from campus</span>" +
          "<span>" + esc(p.address || "No address on the map") + "</span>" +
          "<span>" + esc((p.phone || "No phone") + " \u2013 " + (p.openingHoursRaw || "No hours")) + "</span></button></li>";
      }).join("");
    }).catch(function (e) { mapMsg(e.message, "err"); }).then(function () { btn.disabled = false; });
  }
  function fillFromPlace(p) {
    $("f_name").value = p.name;
    $("f_cat").value = p.category;
    if (p.address) $("f_addr").value = p.address;
    if (p.phone) $("f_phone").value = p.phone;
    state.fill = { lat: p.lat, lng: p.lng, source: p.source, hours: p.hours || null };
    var hoursNote = p.hours ? "Opening hours were added." : p.openingHoursRaw ? "Opening hours \u201c" + p.openingHoursRaw + "\u201d could not be read automatically." : "The map lists no opening hours.";
    mapMsg("Filled from the map: " + p.name + ". " + hoursNote + (p.address ? "" : " No address on the map, so type one.") + " Now add the discount and how to claim it.", "good");
    $("f_disc").focus();
  }
  function adminAction(b) {
    var id = Number(b.dataset.edit || b.dataset.verify || b.dataset.del);
    if (b.dataset.edit) {
      var s = state.shops.filter(function (x) { return x.id === id; })[0];
      if (!s) return;
      state.editing = id; state.fill = null; $("m_q").value = s.name;
      $("f_name").value = s.name; $("f_cat").value = s.category; $("f_status").value = s.status === "sample" ? "sample" : "confirmed";
      $("f_disc").value = s.discount; $("f_claim").value = s.claim; $("f_addr").value = s.address; $("f_phone").value = s.phone || "";
      $("formTitle").textContent = "Edit " + s.name; $("saveBtn").textContent = "Save changes"; $("cancelBtn").hidden = false; setMsg("");
      $("adminPanel").open = true; $("adminPanel").scrollIntoView({ behavior: "smooth", block: "start" }); $("f_disc").focus();
    } else if (b.dataset.verify) {
      api("POST", "/api/shops/" + id + "/verify").then(loadShops).then(renderAll).catch(function (e) { alert(e.message); });
    } else if (b.dataset.del) {
      if (state.armed === id) {
        state.armed = null;
        api("DELETE", "/api/shops/" + id).then(loadShops).then(renderAll).catch(function (e) { alert(e.message); });
      } else { state.armed = id; renderResults(); }
    }
  }

  /* ---------- events ---------- */
  function bind() {
    $("q").addEventListener("input", function (e) { state.q = e.target.value; renderResults(); });
    $("clear").addEventListener("click", function () {
      state.q = ""; state.cat = "All"; state.openOnly = false; state.savedOnly = false; $("q").value = ""; $("q").focus(); renderAll();
    });
    $("filters").addEventListener("click", function (e) {
      var b = e.target.closest("button"); if (!b) return;
      if (b.dataset.cat) state.cat = b.dataset.cat;
      if (b.dataset.open) state.openOnly = !state.openOnly;
      if (b.dataset.saved) state.savedOnly = !state.savedOnly;
      renderFilters(); renderResults();
    });
    $("who").addEventListener("click", function (e) {
      var b = e.target.closest("button"); if (!b) return;
      if (b.id === "acctBtn") { setMenu($("acctMenu").hidden); return; }
      if (b.id === "logoutBtn") logout();
    });
    document.addEventListener("click", function (e) {
      if (!e.target.closest(".acct")) setMenu(false);
    });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape") { var m = $("acctMenu"); if (m && !m.hidden) { setMenu(false); $("acctBtn").focus(); } }
    });
    $("welcome").addEventListener("click", function (e) { if (e.target.id === "welcomeClose") $("welcome").hidden = true; });
    $("saveBtn").addEventListener("click", saveShop);
    $("m_find").addEventListener("click", searchMap);
    $("m_q").addEventListener("keydown", function (e) { if (e.key === "Enter") { e.preventDefault(); searchMap(); } });
    $("m_results").addEventListener("click", function (e) {
      var b = e.target.closest(".m-item"); if (!b) return;
      fillFromPlace(state.found[Number(b.dataset.i)]);
    });
    $("viewSeg").addEventListener("click", function (e) {
      var b = e.target.closest(".seg-btn"); if (b) setView(b.dataset.view);
    });
    $("locateBtn").addEventListener("click", locateMe);
    document.addEventListener("click", function (e) {
      var a = e.target.closest("a[data-goto]"); if (!a) return;
      e.preventDefault(); goToShop(a.dataset.goto);
    });
    $("cancelBtn").addEventListener("click", function () { resetForm(); setMsg(""); });
    $("results").addEventListener("click", function (e) {
      var b = e.target.closest("button"); if (!b) return;
      if (b.dataset.retry) { state.loading = true; renderResults(); return loadShops().then(renderAll); }
      if (b.dataset.save) return toggleSave(Number(b.dataset.save));
      if (isAdmin()) adminAction(b);
    });
  }

  /* ---------- start ---------- */
  $("f_cat").innerHTML = CATEGORIES.map(function (c) { return "<option>" + esc(c) + "</option>"; }).join("");
  bind(); updateClock(); renderAll();
  api("GET", "/api/auth/me").then(function (d) { state.user = d.user; }).catch(function () {})
    .then(loadShops).then(function () { renderAll(); maybeWelcome(); });
  setInterval(function () {
    updateClock();
    var a = document.activeElement;
    if (!a || a.tagName !== "INPUT") renderResults();
  }, 60000);
})();
