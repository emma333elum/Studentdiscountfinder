#!/bin/bash
cd /home/claude/test
node mock.js > mock.log 2>&1 &
SP=$!
sleep 1.5
timeout 60 python3 err.py
kill $SP 2>/dev/null
