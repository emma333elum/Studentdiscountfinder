(function () {
  "use strict";

  var mode = document.body.getAttribute("data-mode"); // "login" or "signup"
  var signup = mode === "signup";
  var form = document.getElementById("authForm");
  var submit = document.getElementById("authSubmit");
  var alertBox = document.getElementById("formAlert");
  var fields = signup ? ["name", "email", "matric", "pass", "pass2"] : ["email", "pass"];

  function $(id) { return document.getElementById(id); }

  /* Already signed in? Go straight to the finder. */
  fetch("/api/auth/me", { credentials: "same-origin" })
    .then(function (r) { return r.json(); })
    .then(function (d) { if (d && d.user) window.location.replace("/"); })
    .catch(function () {});

  /* ---------- show / hide password ---------- */
  Array.prototype.forEach.call(document.querySelectorAll(".pw-toggle"), function (btn) {
    btn.addEventListener("click", function () {
      var input = $(btn.getAttribute("data-for"));
      var show = input.type === "password";
      input.type = show ? "text" : "password";
      btn.textContent = show ? "Hide" : "Show";
      btn.setAttribute("aria-pressed", String(show));
      btn.setAttribute("aria-label", (show ? "Hide " : "Show ") + (btn.getAttribute("data-label") || "password"));
    });
  });

  /* ---------- validation (mirrors the server rules) ---------- */
  var rules = {
    name: function (v) { return v.trim().length < 2 ? "Enter your full name." : ""; },
    email: function (v) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.trim()) ? "" : "Enter a valid email address."; },
    matric: function (v) { return v.trim() && !/^[A-Za-z0-9\/\-]+$/.test(v.trim()) ? "Use only letters, numbers, / and -." : ""; },
    pass: function (v) {
      if (!signup) return v ? "" : "Enter your password.";
      return v.length < 8 ? "Use at least 8 characters." : v.length > 72 ? "Use 72 characters or fewer." : "";
    },
    pass2: function (v) { return v !== $("pass").value ? "The two passwords do not match." : ""; }
  };

  function setErr(name, msg) {
    var input = $(name), box = $("err_" + name);
    if (!input || !box) return;
    box.textContent = msg;
    input.classList.toggle("invalid", !!msg);
    if (msg) input.setAttribute("aria-invalid", "true"); else input.removeAttribute("aria-invalid");
  }
  function check(name) { var msg = rules[name]($(name).value); setErr(name, msg); return !msg; }

  fields.forEach(function (name) {
    var input = $(name);
    input.addEventListener("blur", function () { if (input.value || input.classList.contains("invalid")) check(name); });
    input.addEventListener("input", function () {
      if (input.classList.contains("invalid")) check(name);
      if (name === "pass" && signup) { updateRule(); if ($("pass2").value) check("pass2"); }
    });
  });

  function updateRule() {
    var el = $("ruleLen");
    if (el) el.classList.toggle("met", $("pass").value.length >= 8);
  }

  /* ---------- submit ---------- */
  form.addEventListener("submit", function (e) {
    e.preventDefault();
    alertBox.textContent = "";
    var firstBad = null;
    fields.forEach(function (name) { if (!check(name) && !firstBad) firstBad = name; });
    if (firstBad) { $(firstBad).focus(); return; }

    var body = { email: $("email").value, password: $("pass").value };
    if (signup) { body.name = $("name").value; body.matricNo = $("matric").value; }

    submit.disabled = true;
    var idle = submit.textContent;
    submit.textContent = signup ? "Creating account\u2026" : "Logging in\u2026";

    fetch(signup ? "/api/auth/signup" : "/api/auth/login", {
      method: "POST", credentials: "same-origin",
      headers: { "Content-Type": "application/json" }, body: JSON.stringify(body)
    }).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (data) {
        if (!r.ok) throw new Error(data.error || "Something went wrong. Try again.");
        return data;
      });
    }).then(function () {
      if (signup) { try { sessionStorage.setItem("sdf_welcome", "1"); } catch (err) {} }
      window.location.assign("/");
    }).catch(function (err) {
      var offline = err instanceof TypeError;
      alertBox.textContent = offline ? "Could not reach the server. Check your connection and try again." : err.message;
      submit.disabled = false; submit.textContent = idle;
      alertBox.scrollIntoView({ block: "nearest", behavior: "smooth" });
    });
  });
})();
