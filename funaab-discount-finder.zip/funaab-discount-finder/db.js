const path = require("path");
const fs = require("fs");
const Database = require("better-sqlite3");

// DATA_DIR lets you point the database at a persistent disk when you deploy.
const dataDir = process.env.DATA_DIR || path.join(__dirname, "data");
fs.mkdirSync(dataDir, { recursive: true });

const db = new Database(path.join(dataDir, "discounts.db"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id     TEXT NOT NULL UNIQUE,
    full_name     TEXT NOT NULL,
    email         TEXT NOT NULL UNIQUE COLLATE NOCASE,
    matric_no     TEXT,
    password_hash TEXT NOT NULL,
    role          TEXT NOT NULL DEFAULT 'student' CHECK (role IN ('student','admin')),
    created_at    TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS shops (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name       TEXT NOT NULL UNIQUE COLLATE NOCASE,
    category   TEXT NOT NULL,
    discount   TEXT NOT NULL,
    claim      TEXT NOT NULL,
    address    TEXT NOT NULL,
    phone      TEXT,
    hours      TEXT,
    lat        REAL,
    lng        REAL,
    status     TEXT NOT NULL DEFAULT 'sample' CHECK (status IN ('confirmed','reported','sample')),
    note       TEXT NOT NULL DEFAULT '',
    source     TEXT NOT NULL DEFAULT '',
    checked_at TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS favorites (
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    shop_id    INTEGER NOT NULL REFERENCES shops(id) ON DELETE CASCADE,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    PRIMARY KEY (user_id, shop_id)
  );

  CREATE INDEX IF NOT EXISTS idx_shops_category ON shops(category);
`);

// Opening hours: [Sun, Mon, Tue, Wed, Thu, Fri, Sat], each null (closed) or [openMinute, closeMinute].
const wk = (monSat, sun, sat) => [sun, monSat, monSat, monSat, monSat, monSat, sat === undefined ? monSat : sat];
const CAMPUS = { lat: 7.231, lng: 3.4383 };

const SEED = [
  {
    name: "Agbeloba Black Market", category: "Shopping", status: "reported",
    discount: "20% off all products", claim: "Ask at the counter before you pay",
    address: "On FUNAAB campus", phone: "", hours: null, ...CAMPUS,
    note: "FUNAAB news reported this offer at the market's launch in May 2024. It may have changed since.",
    source: "https://funaab.edu.ng/agbeloba-black-market-launches-with-discounts-at-funaab/",
    checked_at: "2024-05-31T00:00:00.000Z",
  },
  {
    name: "FUNAAB Bookshop", category: "Books", status: "sample",
    discount: "10% off textbooks", claim: "Show your student ID",
    address: "On FUNAAB campus", phone: "", hours: null, ...CAMPUS,
    note: "The shop is real and serves students. The discount is a sample until confirmed.",
    source: "https://funaab.edu.ng/funaab-bookshop-your-one-stop-academic-lifestyle-bookstore",
    checked_at: null,
  },
  {
    name: "Thebookstore", category: "Books", status: "sample",
    discount: "10% off textbooks", claim: "Show your student ID",
    address: "6 Peniel Castle, Accord Estate, FUNAAB, Alabata Road", phone: "+234 803 649 1044",
    hours: wk([540, 1080], null, [540, 960]), lat: 7.22234, lng: 3.45113,
    note: "", source: "", checked_at: null,
  },
  {
    name: "Cheers Café", category: "Food", status: "sample",
    discount: "10% off meals", claim: "Show your student ID",
    address: "School Gate, Alabata Road", phone: "+234 808 127 2870",
    hours: wk([540, 1380], [600, 1380]), lat: 7.22675, lng: 3.45136,
    note: "", source: "", checked_at: null,
  },
  {
    name: "Spices Food and Drinks", category: "Food", status: "sample",
    discount: "10% off", claim: "Show your student ID",
    address: "Alabata Road, near FUNAAB gate", phone: "",
    hours: wk([540, 1290], [1020, 1260]), lat: 7.22658, lng: 3.45188,
    note: "", source: "", checked_at: null,
  },
  {
    name: "Madam Spices Foods Café", category: "Food", status: "sample",
    discount: "5% off bulk orders", claim: "Show your student ID when you order",
    address: "Alabata Road, Alabata", phone: "+234 806 616 5975",
    hours: [[780, 1290], [480, 1320], [480, 1320], [480, 1320], [480, 1320], [480, 1320], [600, 1290]],
    lat: 7.23295, lng: 3.45495, note: "", source: "", checked_at: null,
  },
  {
    name: "SANS Pasta Diner", category: "Food", status: "sample",
    discount: "10% off pasta", claim: "Show your student ID",
    address: "Harmony Estate Road, Alabata", phone: "+234 907 875 8345",
    hours: wk([960, 1260], [960, 1260]), lat: 7.22506, lng: 3.4514,
    note: "", source: "", checked_at: null,
  },
  {
    name: "Alpha Gate Cyber Café and Computers", category: "Tech and print", status: "sample",
    discount: "20% off printing", claim: "Show your student ID",
    address: "No. 4, Alhaja Complex, Alabata Road, off FUNAAB main gate", phone: "+234 706 101 6152",
    hours: wk([0, 1440], [0, 1440]), lat: 7.22726, lng: 3.4516,
    note: "", source: "", checked_at: null,
  },
];

const count = db.prepare("SELECT COUNT(*) AS n FROM shops").get().n;
if (count === 0) {
  const insert = db.prepare(`
    INSERT INTO shops (name, category, discount, claim, address, phone, hours, lat, lng, status, note, source, checked_at)
    VALUES (@name, @category, @discount, @claim, @address, @phone, @hours, @lat, @lng, @status, @note, @source, @checked_at)
  `);
  const seedAll = db.transaction((rows) => {
    rows.forEach((s) => insert.run({ ...s, hours: s.hours ? JSON.stringify(s.hours) : null }));
  });
  seedAll(SEED);
}

module.exports = db;
