# FUNAAB Student Discount Finder

A full-stack web app. Students search shops near FUNAAB, see the discount, how to claim it and whether the shop is open now. They can create an account (each gets an ID like `FUN-482913`) and save shops. The admin adds, edits and deletes shops.

## What is inside

| Part | Tech | File |
|---|---|---|
| Front end (the "dining room") | HTML, CSS, vanilla JS | `public/` |
| Pages | Discount finder `/`, Log in `/login`, Sign up `/signup` | `index.html`, `login.html`, `signup.html` |
| Back end (the "kitchen") | Node.js + Express REST API | `server.js` |
| Database | SQLite (one file) | `db.js` |
| Login | Email + password, bcrypt hashing, JWT in an httpOnly cookie | `server.js` |

### Front end files

| File | Job |
|---|---|
| `public/styles.css` | Shared look and the discount finder layout. Phone first, with one card per row on phones and two on wider screens. |
| `public/auth.css`, `public/auth.js` | Log in and sign up pages: inline validation, show/hide password, error messages from the server. |
| `public/app.js` | The finder: search, filters, saved shops, account menu, admin panel. |

Sign up sends the student to the finder with a welcome message showing their new ID. Anyone who taps Save while logged out is sent to `/login`. The pages load the Bricolage Grotesque and Figtree fonts from Google Fonts and fall back to system fonts if they cannot load.

### Live map (OpenStreetMap)

- **Map view.** The List / Map switch on the finder shows every shop as a pin on an OpenStreetMap map (Leaflet). Tap a pin for the discount, open or closed status, directions and a link to the full card. Filters and search apply to the pins. "Show my location" centres the map on the student.
- **Find on the map (admin).** In the admin panel, search a shop name, or leave it empty to list shops near FUNAAB. Tap a result and the form fills with its name, type, address, phone, position and opening hours. The admin then adds the discount and how to claim it, which no map has.
- Opening hours are read from OpenStreetMap's text format. If a shop has split hours (for example 8:00 to 12:00 and 14:00 to 18:00) the app stores one span from first open to last close. Formats it cannot read are skipped, and the admin sees a message.
- The data comes from OpenStreetMap volunteers, so some shops are missing or have no phone or hours. Treat it as a starting point and confirm offers with the shop. To correct the source, edit the place at openstreetmap.org.
- Needs internet on the server (Overpass API) and on the student's device (map library and tiles). No API key and no cost. Searches are cached for 10 minutes and limited per admin, in line with OpenStreetMap's usage rules.

### API

| Method and path | Who | What |
|---|---|---|
| `POST /api/auth/signup` | anyone | Create account, returns the new student ID |
| `POST /api/auth/login` | anyone | Log in |
| `POST /api/auth/logout` | anyone | Log out |
| `GET /api/auth/me` | anyone | Current user or `null` |
| `GET /api/shops?q=&category=` | anyone | List shops (includes `favorite` when logged in) |
| `POST /api/shops` | admin | Add a shop |
| `PUT /api/shops/:id` | admin | Change a shop or discount |
| `POST /api/shops/:id/verify` | admin | Mark an offer as confirmed today |
| `DELETE /api/shops/:id` | admin | Delete a shop |
| `GET /api/map/search?q=` | admin | Search OpenStreetMap near FUNAAB. Returns name, address, phone, opening hours and position. Empty `q` lists shops near campus. |
| `PUT / DELETE /api/favorites/:shopId` | logged in | Save or unsave a shop |

Requirement mapping: FR1-FR7 are the public search and filters. FR8-FR10 are the admin routes. "Safe" is enforced on the server (`requireAdmin`), not just hidden in the page. Passwords are hashed, login attempts are rate limited, and every input is validated.

## Run it on your computer

1. Install Node.js 18 or newer from nodejs.org.
2. In this folder run:
   ```
   npm install
   cp .env.example .env
   ```
3. Open `.env`. Set `JWT_SECRET` to a long random string and `ADMIN_EMAIL` to your email.
4. Start it:
   ```
   npm start
   ```
5. Open http://localhost:3000. Sign up using the same email as `ADMIN_EMAIL`. That account becomes the admin and sees the admin panel.

## Put it on the internet (Render)

1. Create a free GitHub account and make a new repository. Upload every file in this folder (not `node_modules`, `data` or `.env`; `.gitignore` already skips them).
2. Create an account at render.com and choose **New > Web Service**. Connect your GitHub repository.
3. Use these settings:
   - Runtime: **Node**
   - Build command: `npm install`
   - Start command: `npm start`
4. Under **Environment**, add:
   - `NODE_ENV` = `production`
   - `JWT_SECRET` = a long random string (generate one with `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"`)
   - `ADMIN_EMAIL` = the email you will use for the admin account
5. Deploy. Render gives you a public `https://....onrender.com` link that works on any phone or computer.
6. Open the link, sign up with your `ADMIN_EMAIL`, and you are the admin.

### Important: keeping the data

SQLite stores everything in one file. On hosting plans without a persistent disk, that file is wiped whenever the app redeploys or restarts, so accounts and edits are lost and the 8 starter shops reload. That is fine for a class demo. For real use:

- Add a **persistent disk** to the service (check your host's current plans, as this is usually a paid feature), mount it at `/var/data`, and set `DATA_DIR=/var/data`.
- Or move the database to hosted PostgreSQL. Only `db.js` and the queries in `server.js` would change. Ask for this swap if you want it.

## Before you present or go live

- The discounts marked **Sample** are placeholders. Confirm them with each shop, then use the admin panel to set the real offer and mark it confirmed.
- Add a password reset and email verification if many people will use it.
