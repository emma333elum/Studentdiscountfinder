// Live map lookups from OpenStreetMap (Overpass API). Free, no key. Data (c) OpenStreetMap contributors, ODbL.
const CAMPUS = { lat: 7.231, lng: 3.4383 };
const ENDPOINTS = ["https://overpass-api.de/api/interpreter", "https://overpass.kumi.systems/api/interpreter"];
const UA = "FUNAAB-Student-Discount-Finder/1.0 (student project)";
const FOOD = new Set(["restaurant", "cafe", "fast_food", "food_court", "bar", "pub", "marketplace"]);

/* ---- opening hours: OSM text -> [Sun..Sat] of null | [openMin, closeMin] (the format db.js uses) ---- */
const DAY_ORDER = ["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"]; // OSM week order
const toSun0 = (i) => (i + 1) % 7; // Mo(0)->1 ... Su(6)->0

function parseDays(spec) {
  const out = new Set();
  for (const part of spec.split(",")) {
    const p = part.trim();
    if (!p) continue;
    const m = p.match(/^([A-Za-z]{2})(?:\s*-\s*([A-Za-z]{2}))?$/);
    if (!m) return null; // e.g. PH, week numbers: not supported
    const a = DAY_ORDER.indexOf(m[1]), b = m[2] ? DAY_ORDER.indexOf(m[2]) : a;
    if (a < 0 || b < 0) return null;
    for (let i = a; ; i = (i + 1) % 7) { out.add(toSun0(i)); if (i === b) break; }
  }
  return out;
}
const mins = (t) => { const m = t.match(/^(\d{1,2}):(\d{2})$/); return m ? Number(m[1]) * 60 + Number(m[2]) : NaN; };

function parseOpeningHours(raw) {
  if (typeof raw !== "string" || !raw.trim()) return null;
  const text = raw.trim();
  if (/^24\/7$/i.test(text)) return [0, 1, 2, 3, 4, 5, 6].map(() => [0, 1440]);
  const week = [null, null, null, null, null, null, null];
  for (const rule of text.split(";")) {
    const r = rule.trim();
    if (!r) continue;
    const m = r.match(/^((?:[A-Za-z]{2}(?:\s*-\s*[A-Za-z]{2})?\s*,?\s*)*)\s*(off|closed|\d{1,2}:\d{2}\s*-\s*\d{1,2}:\d{2}(?:\s*,\s*\d{1,2}:\d{2}\s*-\s*\d{1,2}:\d{2})*)$/i);
    if (!m) return null;
    const days = m[1].trim() ? parseDays(m[1].trim()) : new Set([0, 1, 2, 3, 4, 5, 6]);
    if (!days) return null;
    let value = null;
    if (!/^(off|closed)$/i.test(m[2])) {
      let open = Infinity, close = -Infinity;
      for (const span of m[2].split(",")) {
        const [a, b] = span.split("-").map((x) => mins(x.trim()));
        if (isNaN(a) || isNaN(b)) return null;
        open = Math.min(open, a);
        close = Math.max(close, b <= a ? 1440 : b); // past midnight: treat as open to midnight
      }
      value = [Math.max(0, open), Math.min(1440, close)];
    }
    days.forEach((d) => { week[d] = value; });
  }
  return week.some(Boolean) ? week : null;
}

/* ---- query building and result shaping ---- */
function categoryOf(tags) {
  if (FOOD.has(tags.amenity)) return "Food";
  if (["books", "stationery"].includes(tags.shop)) return "Books";
  if (["computer", "electronics", "copyshop", "mobile_phone", "telecommunication"].includes(tags.shop)) return "Tech and print";
  return "Shopping";
}
function addressOf(t) {
  const street = [t["addr:housenumber"], t["addr:street"]].filter(Boolean).join(" ");
  return [street, t["addr:suburb"] || t["addr:neighbourhood"], t["addr:city"] || t["addr:town"]].filter(Boolean).join(", ");
}
function distanceKm(a, b) {
  const R = 6371, rad = (x) => (x * Math.PI) / 180;
  const dLat = rad(b.lat - a.lat), dLng = rad(b.lng - a.lng);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}
function buildQuery(q) {
  const around = (r) => `(around:${r},${CAMPUS.lat},${CAMPUS.lng})`;
  if (q) {
    const safe = q.replace(/[^\p{L}\p{N} '&.-]/gu, "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&").slice(0, 60);
    return `[out:json][timeout:20];nwr["name"~"${safe}",i]${around(15000)};out center tags 25;`;
  }
  return `[out:json][timeout:25];(nwr["name"]["shop"]${around(4000)};` +
    `nwr["name"]["amenity"~"^(restaurant|cafe|fast_food|food_court|bar|pub|marketplace)$"]${around(4000)};);out center tags 60;`;
}
function shape(el) {
  const t = el.tags || {};
  const lat = el.lat != null ? el.lat : el.center && el.center.lat;
  const lng = el.lon != null ? el.lon : el.center && el.center.lon;
  if (!t.name || lat == null || lng == null) return null;
  return {
    osmId: el.type + "/" + el.id, name: t.name, category: categoryOf(t), address: addressOf(t),
    phone: t.phone || t["contact:phone"] || "", website: t.website || t["contact:website"] || "",
    openingHoursRaw: t.opening_hours || "", hours: parseOpeningHours(t.opening_hours), lat, lng,
    source: "https://www.openstreetmap.org/" + el.type + "/" + el.id,
    distanceKm: Math.round(distanceKm(CAMPUS, { lat, lng }) * 10) / 10,
  };
}

const cache = new Map(); // query -> { at, data }
async function overpass(query) {
  let lastErr;
  for (const url of ENDPOINTS) {
    try {
      const r = await fetch(url, {
        method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded", "User-Agent": UA },
        body: "data=" + encodeURIComponent(query), signal: AbortSignal.timeout(25000),
      });
      if (!r.ok) throw new Error("Map service answered " + r.status);
      return await r.json();
    } catch (e) { lastErr = e; }
  }
  throw lastErr || new Error("Map service unavailable");
}

async function searchPlaces(q) {
  const query = buildQuery(q);
  const hit = cache.get(query);
  if (hit && Date.now() - hit.at < 10 * 60 * 1000) return hit.data;
  const json = await overpass(query);
  const seen = new Set();
  const places = (json.elements || []).map(shape).filter(Boolean).filter((p) => {
    const k = p.name.toLowerCase() + p.lat.toFixed(3) + p.lng.toFixed(3);
    if (seen.has(k)) return false; seen.add(k); return true;
  }).sort((a, b) => a.distanceKm - b.distanceKm).slice(0, 40);
  cache.set(query, { at: Date.now(), data: places });
  if (cache.size > 50) cache.delete(cache.keys().next().value);
  return places;
}

module.exports = { searchPlaces, parseOpeningHours, buildQuery, shape, categoryOf };
