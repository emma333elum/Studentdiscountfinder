require("dotenv").config();
const path = require("path");
const crypto = require("crypto");
const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const cookieParser = require("cookie-parser");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const db = require("./db");
const osm = require("./osm");

const PROD = process.env.NODE_ENV === "production";
const PORT = process.env.PORT || 3000;
const ADMIN_EMAIL = (process.env.ADMIN_EMAIL || "").trim().toLowerCase();
const COOKIE_NAME = "sdf_token";
const CATEGORIES = ["Food", "Books", "Tech and print", "Shopping"];
const STATUSES = ["confirmed", "reported", "sample"];

let JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
  if (PROD) {
    console.error("JWT_SECRET is not set. Set it in your hosting dashboard and restart.");
    process.exit(1);
  }
  JWT_SECRET = "dev-only-secret-change-me";
  console.warn("Using a development JWT secret. Do not deploy like this.");
}

const app = express();
app.set("trust proxy", 1); // hosting platforms put a proxy in front of the app
app.use(helmet({
  referrerPolicy: { policy: "strict-origin-when-cross-origin" }, // OpenStreetMap tile servers need a referrer
  contentSecurityPolicy: {
    directives: {
      ...helmet.contentSecurityPolicy.getDefaultDirectives(),
      "script-src": ["'self'", "https://unpkg.com"],        // Leaflet map library
      "style-src": ["'self'", "https:", "'unsafe-inline'"],
      "img-src": ["'self'", "data:", "https://*.tile.openstreetmap.org"], // map tiles
      "upgrade-insecure-requests": PROD ? [] : null, // skip on local http so Safari loads assets
    },
  },
}));
app.use(express.json({ limit: "20kb" }));
app.use(cookieParser());

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, limit: 20, standardHeaders: true, legacyHeaders: false,
  message: { error: "Too many attempts. Wait a few minutes and try again." },
});
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, limit: 600, standardHeaders: true, legacyHeaders: false,
  message: { error: "Too many requests. Slow down and try again soon." },
});
app.use("/api", apiLimiter);
const mapLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, limit: 40, standardHeaders: true, legacyHeaders: false,
  message: { error: "Too many map searches. Wait a few minutes and try again." },
});

/* ---------- helpers ---------- */
const publicUser = (u) => ({ id: u.public_id, name: u.full_name, email: u.email, matricNo: u.matric_no || "", role: u.role });

function newPublicId() {
  for (let i = 0; i < 10; i++) {
    const id = "FUN-" + crypto.randomInt(100000, 1000000);
    if (!db.prepare("SELECT 1 FROM users WHERE public_id = ?").get(id)) return id;
  }
  throw new Error("Could not generate a user ID");
}

function setSession(res, userRowId) {
  const token = jwt.sign({ uid: userRowId }, JWT_SECRET, { expiresIn: "7d" });
  res.cookie(COOKIE_NAME, token, {
    httpOnly: true, sameSite: "lax", secure: PROD, maxAge: 7 * 24 * 60 * 60 * 1000, path: "/",
  });
}

function loadUser(req, _res, next) {
  req.user = null;
  const token = req.cookies[COOKIE_NAME];
  if (token) {
    try {
      const { uid } = jwt.verify(token, JWT_SECRET);
      req.user = db.prepare("SELECT * FROM users WHERE id = ?").get(uid) || null;
    } catch (e) { /* expired or invalid token: treat as logged out */ }
  }
  next();
}
const requireAuth = (req, res, next) =>
  req.user ? next() : res.status(401).json({ error: "Log in to do that." });
const requireAdmin = (req, res, next) =>
  req.user && req.user.role === "admin" ? next() : res.status(403).json({ error: "Only the admin can do that." });

app.use("/api", loadUser);

const clean = (v, max) => (typeof v === "string" ? v.trim().slice(0, max) : "");

function shopToJson(r) {
  return {
    id: r.id, name: r.name, category: r.category, discount: r.discount, claim: r.claim,
    address: r.address, phone: r.phone || "", hours: r.hours ? JSON.parse(r.hours) : null,
    lat: r.lat, lng: r.lng, status: r.status, note: r.note || "", source: r.source || "",
    checkedAt: r.checked_at, favorite: !!r.is_fav,
  };
}

function validateShop(b, existing) {
  const out = {
    name: clean(b.name, 100), category: clean(b.category, 40), discount: clean(b.discount, 100),
    claim: clean(b.claim, 200), address: clean(b.address, 200), phone: clean(b.phone, 30),
    status: clean(b.status, 20) || "sample",
  };
  if (!out.name || !out.discount || !out.claim || !out.address) {
    return { error: "Name, discount, how to claim and address are required." };
  }
  if (!CATEGORIES.includes(out.category)) return { error: "Pick a valid type." };
  if (!STATUSES.includes(out.status)) return { error: "Pick a valid offer status." };

  let hours = existing ? existing.hours : null;
  if (b.hours !== undefined) {
    if (b.hours === null) hours = null;
    else {
      const ok = Array.isArray(b.hours) && b.hours.length === 7 && b.hours.every((d) =>
        d === null || (Array.isArray(d) && d.length === 2 && d.every((n) => Number.isInteger(n) && n >= 0 && n <= 1440)));
      if (!ok) return { error: "Opening hours must list 7 days." };
      hours = JSON.stringify(b.hours);
    }
  }
  out.hours = hours;
  const num = (v, fallback) => (typeof v === "number" && isFinite(v) ? v : fallback);
  out.lat = num(b.lat, existing ? existing.lat : null);
  out.lng = num(b.lng, existing ? existing.lng : null);
  out.note = b.note !== undefined ? clean(b.note, 300) : existing ? existing.note : "";
  out.source = b.source !== undefined ? clean(b.source, 300) : existing ? existing.source : "";
  return { value: out };
}

/* ---------- auth ---------- */
app.post("/api/auth/signup", authLimiter, (req, res) => {
  const name = clean(req.body.name, 80);
  const email = clean(req.body.email, 120).toLowerCase();
  const matric = clean(req.body.matricNo, 20);
  const password = typeof req.body.password === "string" ? req.body.password : "";

  if (name.length < 2) return res.status(400).json({ error: "Enter your full name." });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: "Enter a valid email address." });
  if (matric && !/^[A-Za-z0-9\/\-]+$/.test(matric)) return res.status(400).json({ error: "Matric number can only use letters, numbers, / and -." });
  if (password.length < 8 || password.length > 72) return res.status(400).json({ error: "Password must be 8 to 72 characters." });
  if (db.prepare("SELECT 1 FROM users WHERE email = ?").get(email)) {
    return res.status(409).json({ error: "An account with this email already exists. Log in instead." });
  }

  const role = ADMIN_EMAIL && email === ADMIN_EMAIL ? "admin" : "student";
  const info = db.prepare(
    "INSERT INTO users (public_id, full_name, email, matric_no, password_hash, role) VALUES (?,?,?,?,?,?)"
  ).run(newPublicId(), name, email, matric || null, bcrypt.hashSync(password, 10), role);
  const user = db.prepare("SELECT * FROM users WHERE id = ?").get(info.lastInsertRowid);
  setSession(res, user.id);
  res.status(201).json({ user: publicUser(user) });
});

const DUMMY_HASH = bcrypt.hashSync("not-a-real-password", 10);
app.post("/api/auth/login", authLimiter, (req, res) => {
  const email = clean(req.body.email, 120).toLowerCase();
  const password = typeof req.body.password === "string" ? req.body.password : "";
  const user = db.prepare("SELECT * FROM users WHERE email = ?").get(email);
  const ok = bcrypt.compareSync(password, user ? user.password_hash : DUMMY_HASH);
  if (!user || !ok) return res.status(401).json({ error: "Wrong email or password." });
  setSession(res, user.id);
  res.json({ user: publicUser(user) });
});

app.post("/api/auth/logout", (_req, res) => {
  res.clearCookie(COOKIE_NAME, { path: "/" });
  res.json({ ok: true });
});

app.get("/api/auth/me", (req, res) => {
  res.json({ user: req.user ? publicUser(req.user) : null });
});

/* ---------- shops ---------- */
app.get("/api/shops", (req, res) => {
  const q = clean(req.query.q, 100).toLowerCase();
  const cat = clean(req.query.category, 40);
  const rows = db.prepare(`
    SELECT s.*, CASE WHEN f.user_id IS NULL THEN 0 ELSE 1 END AS is_fav
    FROM shops s LEFT JOIN favorites f ON f.shop_id = s.id AND f.user_id = ?
    ORDER BY s.name COLLATE NOCASE
  `).all(req.user ? req.user.id : -1);
  const list = rows
    .filter((r) => (!cat || r.category === cat) && (!q || r.name.toLowerCase().includes(q)))
    .map(shopToJson);
  res.json({ shops: list });
});

function conflict(err, res, next) {
  if (err && String(err.code).startsWith("SQLITE_CONSTRAINT")) {
    return res.status(409).json({ error: "A shop with this name is already listed. Edit that entry instead." });
  }
  return next(err);
}

app.post("/api/shops", requireAdmin, (req, res, next) => {
  const v = validateShop(req.body, null);
  if (v.error) return res.status(400).json({ error: v.error });
  const s = v.value;
  try {
    const info = db.prepare(`
      INSERT INTO shops (name, category, discount, claim, address, phone, hours, lat, lng, status, note, source, checked_at)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
    `).run(s.name, s.category, s.discount, s.claim, s.address, s.phone, s.hours, s.lat, s.lng, s.status, s.note, s.source,
      s.status === "confirmed" ? new Date().toISOString() : null);
    const row = db.prepare("SELECT *, 0 AS is_fav FROM shops WHERE id = ?").get(info.lastInsertRowid);
    res.status(201).json({ shop: shopToJson(row) });
  } catch (err) { conflict(err, res, next); }
});

app.put("/api/shops/:id", requireAdmin, (req, res, next) => {
  const existing = db.prepare("SELECT * FROM shops WHERE id = ?").get(req.params.id);
  if (!existing) return res.status(404).json({ error: "Shop not found." });
  const v = validateShop(req.body, existing);
  if (v.error) return res.status(400).json({ error: v.error });
  const s = v.value;
  try {
    db.prepare(`
      UPDATE shops SET name=?, category=?, discount=?, claim=?, address=?, phone=?, hours=?, lat=?, lng=?,
        status=?, note=?, source=?, checked_at=?, updated_at=datetime('now') WHERE id=?
    `).run(s.name, s.category, s.discount, s.claim, s.address, s.phone, s.hours, s.lat, s.lng, s.status,
      s.status === "confirmed" ? "" : s.note, s.source,
      s.status === "confirmed" ? new Date().toISOString() : existing.checked_at, existing.id);
    const row = db.prepare("SELECT *, 0 AS is_fav FROM shops WHERE id = ?").get(existing.id);
    res.json({ shop: shopToJson(row) });
  } catch (err) { conflict(err, res, next); }
});

app.post("/api/shops/:id/verify", requireAdmin, (req, res) => {
  const info = db.prepare(
    "UPDATE shops SET status='confirmed', note='', checked_at=?, updated_at=datetime('now') WHERE id=?"
  ).run(new Date().toISOString(), req.params.id);
  if (!info.changes) return res.status(404).json({ error: "Shop not found." });
  const row = db.prepare("SELECT *, 0 AS is_fav FROM shops WHERE id = ?").get(req.params.id);
  res.json({ shop: shopToJson(row) });
});

app.delete("/api/shops/:id", requireAdmin, (req, res) => {
  const info = db.prepare("DELETE FROM shops WHERE id = ?").run(req.params.id);
  if (!info.changes) return res.status(404).json({ error: "Shop not found." });
  res.json({ ok: true });
});

/* ---------- live map lookup (admin only): OpenStreetMap ---------- */
app.get("/api/map/search", requireAdmin, mapLimiter, async (req, res) => {
  try {
    const places = await osm.searchPlaces(clean(req.query.q, 60));
    res.json({ places, attribution: "Map data \u00a9 OpenStreetMap contributors" });
  } catch (err) {
    console.error("Map lookup failed:", err.message);
    res.status(502).json({ error: "Could not reach the map service. Try again in a minute." });
  }
});

/* ---------- saved shops (per user) ---------- */
app.put("/api/favorites/:shopId", requireAuth, (req, res) => {
  const shop = db.prepare("SELECT id FROM shops WHERE id = ?").get(req.params.shopId);
  if (!shop) return res.status(404).json({ error: "Shop not found." });
  db.prepare("INSERT OR IGNORE INTO favorites (user_id, shop_id) VALUES (?, ?)").run(req.user.id, shop.id);
  res.json({ ok: true });
});
app.delete("/api/favorites/:shopId", requireAuth, (req, res) => {
  db.prepare("DELETE FROM favorites WHERE user_id = ? AND shop_id = ?").run(req.user.id, req.params.shopId);
  res.json({ ok: true });
});

/* ---------- misc ---------- */
app.get("/api/health", (_req, res) => res.json({ ok: true }));
app.use("/api", (_req, res) => res.status(404).json({ error: "Not found." }));

// extensions lets /login and /signup open login.html and signup.html
app.use(express.static(path.join(__dirname, "public"), { extensions: ["html"] }));

// eslint-disable-next-line no-unused-vars
app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: "Something went wrong on the server." });
});

app.listen(PORT, () => console.log("Student Discount Finder running on port " + PORT));
